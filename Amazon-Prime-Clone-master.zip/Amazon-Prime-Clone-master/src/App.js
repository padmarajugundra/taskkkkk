import { AllRoutes } from "./Components/Routes/AllRoutes";
import { useSelector } from "react-redux";

function App() {
  // trying adding redux here because

  return (
    <>
      <AllRoutes />
    </>
  );
}

export default App;
